package com.example.stockspring.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.stockspring.model.Company;

@Repository
public class CompanyDaoImpl implements CompanyDao {

	public List<Company> getCompanyList() throws SQLException {
		System.out.println("dao int");
		List<Company> companyList = new ArrayList<Company>();
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/stock_db", "root", "root");
			PreparedStatement ps = conn.prepareStatement("select * from company");
			ResultSet rs = ps.executeQuery();
			Company company = null;
			while (rs.next()) {
				company = new Company();
				int companyId = rs.getInt("company_code");
				company.setCompanyId(companyId);
				company.setCompanyName(rs.getString("company_name"));
				company.setTurnOver(rs.getFloat("company_turnover"));
				company.setCompanyCEO(rs.getString("company_ceo"));
				company.setBoardOfDirectors(rs.getString("board_of_directors"));
				company.setCompanyBrief(rs.getString("company_brief"));

				companyList.add(company);
			}
		} catch (SQLException e) {
			System.out.println("dao exception");
			System.out.println(e);
			throw e;
		}
		return companyList;

	}

}
